<?php
require_once 'hybrid/hybd/src/autoload.php';

use Hybridauth\Hybridauth;

$config = [
  'callback' => 'https://localhost/hybridauth/index.php',
  'providers' => [
    'Facebook' => [
      'enabled' => true,
      'keys' => [
        'id' => '954036275721025',
        'secret' => 'a1933e04f49fa1df99ab0854a61ca786'
      ],
      'scope' => 'email, user_about_me, user_birthday, user_hometown'
    ]
  ]
];

$hybridauth = new Hybridauth($config);
// Authenticate users with Facebook
$adapter = $hybridauth->authenticate('Facebook');

// Get user profile data
$userProfile = $adapter->getUserProfile();

// Print user profile data
echo '<pre>' . print_r($userProfile, true) . '</pre>';

// Disconnect the adapter
$adapter->disconnect();
?>